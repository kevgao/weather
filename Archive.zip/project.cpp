#define GLFW_INCLUDE_NONE
#include "glad.h"
#include "CSCIx229.h"
#include "glm/glm.hpp"
//#include "glm/gtc/matrix_transform.hpp"
#include "glm/gtc/type_ptr.hpp"
#include "glm/gtx/string_cast.hpp"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include <GLFW/glfw3.h>
#include <iostream>
#include <cmath>

#define	MAX_PARTICLES	200

GLuint WIDTH = 800, HEIGHT = 600;
 
#define VERTEX_SHADER ("#version 330 core\n\
layout (location = 0) in vec3 position;\n\
layout (location = 1) in vec3 dnorm;\n\
layout (location = 2) in vec2 dtexCoord;\n\
out vec3 norm;\n\
out vec2 texCoord;\n\
uniform mat4 model;\n\
uniform mat4 view;\n\
uniform mat4 projection;\n\
void main(){\n\
gl_Position =  projection * view * model * vec4(position, 1.0f);\n\
norm = dnorm; \n\
texCoord = dtexCoord; \n\
}\0")

#define FRAGMENT_SHADER ("#version 330 core\n\
in vec3 norm;\n\
in vec2 texCoord;\n\
out vec4 fragColor;\n\
uniform sampler2D ourTexture;\n\
void main(){\n\
fragColor = texture(ourTexture, texCoord);\n\
}\0")


typedef struct 				
{
	bool	active;				
	float	life;				
	float	fade;				
	float	r;				
	float	g;				
	float	b;				
	float	x;				
	float	y;				
	float	z;				
	float	xi;				
	float	yi;				
	float	zi;				
	float	xg;				
	float	yg;				
	float	zg;				
}particles;	


particles particle[MAX_PARTICLES];
particles particleStar[MAX_PARTICLES];
particles particleRain[MAX_PARTICLES+800];
particles particleSnow[MAX_PARTICLES+800];



GLfloat vertices[] = {
    1.0f, 0.0f, 1.0f, 1.0f, 0.0f, 0.0f, 1.0f, 1.0f,
    1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f,
    0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f,
    0.0f, 0.0f, 1.0f, 1.0f, 1.0f, 0.0f, 0.0f, 1.0f
};

GLuint VAO;
GLuint VBO;
GLuint shaderProgram;

glm::mat4 model;
glm::mat4 view;
glm::mat4 projection;

glm::vec3 cameraPos = glm::vec3(0.0f, 0.2f, -0.2f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);

GLboolean firstMouse = true;
GLfloat cursorX=400, cursorY=300;
GLfloat yaw = -90.0f, pitch = 0.0f;

int loop;
GLfloat slowdown = 1.0;
GLfloat zoom = 0.05f;



GLuint texture[20];
GLuint partTexture = texture[9];

void framebuffer_size_callback(GLFWwindow* window, int width, int height){
    glViewport(0,0,width,height);
}

void key_callback(GLFWwindow* window, int key, int scancode, int action, int mode){

    GLfloat cameraSpeed = 0.05f;
    if(key == GLFW_KEY_W){
        cameraPos += cameraSpeed * cameraFront;
    }
    if(key == GLFW_KEY_S)
        cameraPos -= cameraSpeed * cameraFront;
        //view = glm::translate(view, glm::vec3(0.0f, 0.0f, -0.05));
    if(key == GLFW_KEY_A)
        cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp))*cameraSpeed;
        //view = glm::translate(view, glm::vec3(0.05f, 0.0f, 0.0f));
    if(key == GLFW_KEY_D)
        cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp))*cameraSpeed;
        //view = glm::translate(view, glm::vec3(-0.05f, 0.0f, 0.0f));

    view = glm::lookAt(cameraPos, cameraPos+cameraFront, cameraUp);

}

void mouse_callback(GLFWwindow* window, double xpos, double ypos){

    

    if(firstMouse){
        cursorX = xpos;
        cursorY = ypos;
        firstMouse = false;
    }

    GLfloat xoffset = xpos - cursorX;
    GLfloat yoffset = cursorY - ypos;
    cursorX = xpos;
    cursorY = ypos;

    GLfloat sensitivity = 0.1;
    xoffset *= sensitivity;
    yoffset *= sensitivity;

    yaw += xoffset;
    pitch += yoffset;

    if(pitch > 89.0f) pitch = 89.0f;
    if(pitch < -89.0f) pitch = -89.0f;

    glm::vec3 front;
    front.x = cos(glm::radians(yaw))*cos(glm::radians(pitch));
    front.y = sin(glm::radians(pitch));
    front.z = sin(glm::radians(yaw))*cos(glm::radians(pitch));
    cameraFront = glm::normalize(front);

    view = glm::lookAt(cameraPos, cameraPos+cameraFront, cameraUp);
    
}

void initParticle(GLuint file){
    //partTexture = texture[9]
	//partTexture = file;
	for (loop=0;loop<MAX_PARTICLES;loop++){
		particle[loop].active=true;				
		particle[loop].life=0.5f;										      
		particle[loop].fade=10.0;
		particle[loop].r=174.0/255.0;
		particle[loop].g=237.0/255.0;
		particle[loop].b=69.0/255.0;
		particle[loop].x=(float(rand()%25+19));	
		particle[loop].y=(float(rand()%20));	
		particle[loop].z=-float(rand()%28)+4;	
		
		particle[loop].xi=float((rand()%50)-25.0f)*10.0f;
		particle[loop].yi=float((rand()%50)-25.0f)*10.0f;
		particle[loop].zi=float((rand()%50)-25.0f)*10.0f;
	}
	for (loop=0;loop<MAX_PARTICLES;loop++){
		particleStar[loop].active=true;				
		particleStar[loop].life=1.0f;										      
		particleStar[loop].fade=10.0;
		particleStar[loop].r=1.0;
		particleStar[loop].g=1.0;
		particleStar[loop].b=1.0;	
		particleStar[loop].x=(float(rand()%600)-220);	
		particleStar[loop].y=100.0f;	
		particleStar[loop].z=(float(rand()%520)-220);	
	}
	for (loop=0;loop<MAX_PARTICLES+800;loop++){
		particleRain[loop].active=true;				
		particleRain[loop].life=1.0f;										      
		particleRain[loop].fade=10.0;
		particleRain[loop].r=1.0;
		particleRain[loop].g=0.5;
		particleRain[loop].b=0.5;
		particleRain[loop].xi=0;		
		particleRain[loop].yi=5;	
		particleRain[loop].zi=0;				   
		particleRain[loop].xg=0.0f;					
		particleRain[loop].yg=-0.9f;				
		particleRain[loop].zg=0.0f;
	}
	for (loop=0;loop<MAX_PARTICLES+800;loop++){
		particleSnow[loop].active=true;				
		particleSnow[loop].life=0.6f;										      
		particleSnow[loop].fade=float(rand()%100)/1000.0f;	 
		particleSnow[loop].r=0.5;
		particleSnow[loop].g=0.5;
		particleSnow[loop].b=0.5;
		particleSnow[loop].x=(float(rand()%200)-64);	
		particleSnow[loop].y=(float(rand()%10)+55);	
		particleSnow[loop].z=float(rand()%160)-64;	
		particleSnow[loop].xi=float((rand()%100)-50.0f);
		particleSnow[loop].yi=-float((rand()%30)+60);
		particleSnow[loop].zi=0;				   
		particleSnow[loop].xg=0.3f;					
		particleSnow[loop].yg=-0.9f;				
		particleSnow[loop].zg=0.0f;
	}
}

void drawParticle(){
	
	glEnable(GL_BLEND);	
	glDisable(GL_DEPTH_TEST);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);
	
	for (loop=0;loop<MAX_PARTICLES;loop++){
		if (particle[loop].active){

	        float x=particle[loop].x;		
			float y=particle[loop].y;		
			float z=particle[loop].z+zoom;		
			glColor4f(particle[loop].r,particle[loop].g,particle[loop].b,particle[loop].life);
			glBindTexture(GL_TEXTURE_2D, partTexture);
			glBegin(GL_TRIANGLE_STRIP);		
		    glTexCoord2d(1,1); glVertex3f(x+0.3f,y+0.3f,z); 
			glTexCoord2d(0,1); glVertex3f(x-0.3f,y+0.3f,z); 
			glTexCoord2d(1,0); glVertex3f(x+0.3f,y-0.3f,z); 
			glTexCoord2d(0,0); glVertex3f(x-0.3f,y-0.3f,z); 
			glEnd();				
			particle[loop].x+=particle[loop].xi/(slowdown*20000);
			particle[loop].y+=particle[loop].yi/(slowdown*20000);
			particle[loop].z+=particle[loop].zi/(slowdown*20000);
			particle[loop].xi+=particle[loop].xg;	
			particle[loop].yi+=particle[loop].yg;	
			particle[loop].zi+=particle[loop].zg;	
			particle[loop].life-=0.1*particle[loop].fade;


		    if (particle[loop].life<0.0f){

			    particle[loop].life=0.5f;	
			    particle[loop].fade=float(rand()%100)/1000.0f;
			    particle[loop].x=(float(rand()%23+21));	
			    particle[loop].y=(float(rand()%10+2));	
			    particle[loop].z=float(rand()%24+1);	
				
			    particle[loop].xi=float((rand()%50)-25.0f)*10.0f;
			    particle[loop].yi=float((rand()%50)-25.0f)*10.0f;
			    particle[loop].zi=float((rand()%50)-25.0f)*10.0f;
	        }
        }
    }
	
		for (loop=0;loop<MAX_PARTICLES;loop++)
	{
		if (particleStar[loop].active)
		{

	        float x=particleStar[loop].x;		
			float y=particleStar[loop].y;		
			float z=particleStar[loop].z;		
			glBindTexture(GL_TEXTURE_2D, partTexture);
			glColor4f(particleStar[loop].r,particleStar[loop].g,particleStar[loop].b,particleStar[loop].life);
			glBegin(GL_TRIANGLE_STRIP);		
		    glTexCoord2d(1,1); glVertex3f(x+0.9f,y,z+0.9f); 
			glTexCoord2d(0,1); glVertex3f(x-0.9f,y,z+0.9f); 
			glTexCoord2d(1,0); glVertex3f(x+0.9f,y,z-0.9f); 
			glTexCoord2d(0,0); glVertex3f(x-0.9f,y,z-0.9f); 
			glEnd();				
			particleStar[loop].life-=0.1*particleStar[loop].fade;

		if (particleStar[loop].life<0.0f)				
			{
				particleStar[loop].life=0.35f;	
				particleStar[loop].fade=float(rand()%100)/1000.0f+0.005f;
				particleStar[loop].x=(float(rand()%600)-220);	
				particleStar[loop].y=100.0f;	
				particleStar[loop].z=(float(rand()%520)-220);	
			}

		}}
		
	glEnable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);		
	
}


void snow(){
	glPushMatrix();
	
	glEnable(GL_BLEND);	
	glDisable(GL_DEPTH_TEST);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);

	for (loop=0;loop<100;loop++){
        std::cout << "snow" << std::endl;
		if (particleSnow[loop].active){

	        float x=particleSnow[loop].x;		
			float y=particleSnow[loop].y;		
			float z=particleSnow[loop].z+zoom;		
			glColor4f(particleSnow[loop].r,particleSnow[loop].g,particleSnow[loop].b,particleSnow[loop].life);
			glBindTexture(GL_TEXTURE_2D, texture[9]);
			glBegin(GL_TRIANGLE_STRIP);		
		    glTexCoord2d(1,1); glVertex3f(x+0.8f,y+0.8f,z); 
			glTexCoord2d(0,1); glVertex3f(x-0.8f,y+0.8f,z); 
			glTexCoord2d(1,0); glVertex3f(x+0.8f,y-0.8f,z); 
			glTexCoord2d(0,0); glVertex3f(x-0.8f,y-0.8f,z); 
			glEnd();				
			particleSnow[loop].x+=particleSnow[loop].xi/(slowdown*300);
			particleSnow[loop].y+=particleSnow[loop].yi/(slowdown*300);
			particleSnow[loop].z+=particleSnow[loop].zi/(slowdown*300);
			particleSnow[loop].xi+=particleSnow[loop].xg;	
			particleSnow[loop].yi+=particleSnow[loop].yg;	
			particleSnow[loop].zi+=particleSnow[loop].zg;	
			particleSnow[loop].life-=0.3*particleSnow[loop].fade;

			/*if(particle[loop].y<-3.0f)
			{
               particle[loop].xi=particle[loop].xi;	
	        	particle[loop].yi=-particle[loop].yi;		
			}*/


		if (particleSnow[loop].life<0.0f){
				particleSnow[loop].life=0.6f;	
				particleSnow[loop].fade=float(rand()%100)/1000.0f;
				particleSnow[loop].x=(float(rand()%200)-64);	
				particleSnow[loop].y=(float(rand()%10)+55);	
				particleSnow[loop].z=float(rand()%160)-64;	
				particleSnow[loop].xi=float((rand()%100)-50.0f);
				particleSnow[loop].yi=-float((rand()%30)+60);
				particleSnow[loop].zi=0;	//float((rand()%50)-25.0f)*10.0f;
			}

		}
	}
	glEnable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);
	glPopMatrix();
}



void landscape(){

    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture[6]);
    glPushMatrix();
    glBegin(GL_QUAD_STRIP);
    glColor3f(1,1,1);
    glNormal3d(0,1,0);
    glVertex3f(-0.8, 0, -1);
    glTexCoord2f(0,0);
    glVertex3f(0.8, 0, -1);
    glTexCoord2f(1,0);
    glVertex3f(-0.8, 0, 1);
    glTexCoord2f(0,1);
    glVertex3f(0.8, 0, 1);
    glTexCoord2f(1,1);
    std::cout << "landscape" << std::endl;
    
glEnd();
glPopMatrix();

}


void house(){

    glUseProgram(shaderProgram);
    GLint modelLoc = glGetUniformLocation(shaderProgram, "model");
    GLint viewLoc = glGetUniformLocation(shaderProgram, "view");
    GLint projLoc = glGetUniformLocation(shaderProgram, "projection");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, texture[14]);
    glBindVertexArray(VAO);
    glDrawArrays(GL_TRIANGLE_FAN, 0, 3);
    //glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
    glBindVertexArray(0);


}

void skybox(float x, float y, float z, float box_width, float box_height,float box_length){
    // draw sky
	
	float width =  box_width;
	float height = box_height;
	float length =  box_length;
	
	glPushMatrix();
    glEnable(GL_TEXTURE_2D);
	
	glBindTexture(GL_TEXTURE_2D, texture[0]);
   
	glBegin(GL_QUADS);		
		
	glTexCoord2f(1.0f, 0.0f); glVertex3f(x + width, y,			z);
	glTexCoord2f(1.0f, 1.0f); glVertex3f(x + width, y + height, z); 
	glTexCoord2f(0.0f, 1.0f); glVertex3f(x,			y + height, z);
	glTexCoord2f(0.0f, 0.0f); glVertex3f(x,			y,			z);
	glEnd();

	glBindTexture(GL_TEXTURE_2D, texture[2]);

	glBegin(GL_QUADS);	
	glTexCoord2f(1.0f, 0.0f); glVertex3f(x,			y,			z + length);
	glTexCoord2f(1.0f, 1.0f); glVertex3f(x,			y + height, z + length);
	glTexCoord2f(0.0f, 1.0f); glVertex3f(x + width, y + height, z + length); 
	glTexCoord2f(0.0f, 0.0f); glVertex3f(x + width, y,			z + length);

	glEnd();

	glBindTexture(GL_TEXTURE_2D, texture[4]);
	
	glBegin(GL_QUADS);		
		
	glTexCoord2f(0.0f, 1.0f); glVertex3f(x + width, y + height, z);
	glTexCoord2f(0.0f, 0.0f); glVertex3f(x + width, y + height, z + length); 
	glTexCoord2f(1.0f, 0.0f); glVertex3f(x,			y + height,	z + length);
	glTexCoord2f(1.0f, 1.0f); glVertex3f(x,			y + height,	z);
		
	glEnd();
	
	
	glBindTexture(GL_TEXTURE_2D, texture[3]);
	
	glBegin(GL_QUADS);		
		
	glTexCoord2f(1.0f, 1.0f); glVertex3f(x,			y + height,	z);	
	glTexCoord2f(0.0f, 1.0f); glVertex3f(x,			y + height,	z + length); 
	glTexCoord2f(0.0f, 0.0f); glVertex3f(x,			y,			z + length);
	glTexCoord2f(1.0f, 0.0f); glVertex3f(x,			y,			z);		
		
	glEnd();

	glBindTexture(GL_TEXTURE_2D, texture[1]);
	glBegin(GL_QUADS);		

	glTexCoord2f(0.0f, 0.0f); glVertex3f(x + width, y,			z);
	glTexCoord2f(1.0f, 0.0f); glVertex3f(x + width, y,			z + length);
	glTexCoord2f(1.0f, 1.0f); glVertex3f(x + width, y + height,	z + length); 
	glTexCoord2f(0.0f, 1.0f); glVertex3f(x + width, y + height,	z);
	glEnd();

    glPopMatrix();                 

}

GLuint loadTexture(std::string filename, int width = 1024, int height = 512, int comp = 24){
    
    unsigned char* image = stbi_load(filename.c_str(), &width, &height, &comp, STBI_rgb_alpha);
    GLuint tex;
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
    glGenerateMipmap(GL_TEXTURE_2D);
    stbi_image_free(image);
    glBindTexture(GL_TEXTURE_2D, 0);

    return tex;

}

void init(){

    //GLfloat Translate = 1;
    model = glm::scale(glm::mat4(1.0f), glm::vec3(2.0f));
    
    //view = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, -Translate));
    //gluPerspective()
    view = glm::lookAt(cameraPos, cameraPos+cameraFront, cameraUp);
    std::cout << glm::to_string(view) << std::endl;

    projection = glm::perspective(45.0f, (GLfloat)WIDTH/(GLfloat)HEIGHT, 0.1f, 200.0f);
    std::cout << glm::to_string(projection) << std::endl;

    int iheight = 512;
    int iwidth = 1024;
    int idepth = 24;

    //std::cout << model << std::endl;

    texture[0] = loadTexture("image/sky_1.bmp", 10, 5, idepth);
    texture[1] = loadTexture("image/sky_2.bmp", iwidth, iheight, idepth);
    texture[2] = loadTexture("image/sky_3.bmp", iwidth, iheight, idepth);
    texture[3] = loadTexture("image/sky_4.bmp", iwidth, iheight, idepth);
    texture[4] = loadTexture("image/sky.bmp", iwidth, iheight, idepth);
    //texture[5] = loadTexture("image/qiang4.bmp", iwidth, iheight, 36);
    texture[5] = loadTexture("Image/shu.bmp");
	texture[6] = loadTexture("Image/shu1.bmp");
	texture[7] = loadTexture("Image/tiao.bmp");
	texture[8] = loadTexture("Image/door.bmp");
	texture[9] = loadTexture("Image/star.bmp");
	texture[10] = loadTexture("Image/shu1_1.bmp");
	texture[11] = loadTexture("Image/shu1_2.bmp");
	texture[12] = loadTexture("Image/shu2_1.bmp");
	texture[13] = loadTexture("Image/shu2_2.bmp");
	texture[14] = loadTexture("Image/cao_1.bmp");
	texture[15] = loadTexture("Image/cao_2.bmp");
	texture[16] = loadTexture("Image/fire.bmp");
	texture[17] = loadTexture("Image/start_1.bmp");	
	texture[18] = loadTexture("Image/start_2.bmp");
	texture[19] = loadTexture("Image/Particle.bmp");
	
    

    // vertex shader
    const char* vertexShaderSource = VERTEX_SHADER;
    GLuint vertexShader;
    vertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
    glCompileShader(vertexShader);

    int success;
    char infoLog[512];
    glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);
    if(!success){
        glGetShaderInfoLog(vertexShader, 512, NULL, infoLog);
        std::cout << "error compiling vertex shader:" << infoLog << std::endl;
    }

    // fragment shader

    const char* fragmentShaderSource = FRAGMENT_SHADER;
    GLuint fragmentShader;
    fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
    glCompileShader(fragmentShader);

    glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &success);
    if(!success){
        glGetShaderInfoLog(fragmentShader, 512, NULL, infoLog);
        std::cout << "error compiling fragment shader:" << infoLog << std::endl;
    }

    shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShader);
    glAttachShader(shaderProgram, fragmentShader);
    glLinkProgram(shaderProgram);

    glGetProgramiv(shaderProgram, GL_LINK_STATUS, &success);
    if(!success){
        glGetProgramInfoLog(shaderProgram, 512, NULL, infoLog);
        std::cout << "error linking program:" << infoLog << std::endl;
    }

    //glUseProgram(shaderProgram);
    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);

    glGenVertexArrays(1, &VAO);
    glBindVertexArray(VAO);
    
    
    glGenBuffers(1, &VBO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    glVertexAttribPointer(0,3,GL_FLOAT, GL_FALSE, 8*sizeof(float), (GLvoid*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1,3,GL_FLOAT, GL_FALSE, 8*sizeof(float), (GLvoid*)(3*sizeof(GLfloat)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2,2,GL_FLOAT, GL_FALSE, 8*sizeof(float), (GLvoid*)(6*sizeof(GLfloat)));
    glEnableVertexAttribArray(2);

    

}

void render(){

    //glClearColor(0.2f, 0.3f, 0.3f,1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();

    
    //landscape();
    house();
    //snow();

    //snow();
    
    
    //GLfloat LightAmbient[] = {1.0f, 1.0f, 1.0f, 1.0f};
    //GLfloat LightDiffuse[] = {1.0f, 1.0f, 1.0f, 1.0f};
    //glMaterialfv( GL_FRONT, GL_AMBIENT, LightAmbient);
    //glMaterialfv( GL_FRONT, GL_DIFFUSE, LightDiffuse);
    skybox(0,0,0,100,100,100);
    //glEnable(GL_LIGHT0);


}

int main( int argc, char *argv[]){

    //GLFW init
    if (!glfwInit()){
        return 0;
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 2);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);


    // create window
    GLFWwindow* window = glfwCreateWindow(800, 600, "Weather System", NULL, NULL);
    if (!window){
        std::cout << "Failed to create window" << std::endl;
        glfwTerminate();
        return 0;
    }
    
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glfwSetKeyCallback(window, key_callback);
    glfwSetCursorPosCallback(window, mouse_callback);

    // glad
    if (! gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)){
        std::cout << "Failed to initialize GLAD" << std::endl;
        return 0;
    }

    int width, height;
    glfwGetFramebufferSize(window,&width, &height);
    //glViewport(0,0,width, height);

    init();

    while (!glfwWindowShouldClose(window)){


        //main render function
        render();

        // swap buffer
        glfwSwapBuffers(window);

        // events
        glfwPollEvents();
        

    }

    glfwTerminate();

    return 0;
}

